<!-- plugins:js -->
<script src="{{ asset('/vendors/js/vendor.bundle.base.js') }}"></script>
  <script src="{{ asset('/vendors/js/vendor.bundle.addons.js') }}"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="{{ asset('/js/off-canvas.js') }}"></script>
  <script src="{{ asset('/js/misc.js') }}"></script>
  <script src="{{ asset('/js/scripts.js') }}"></script>
  <!-- endinject -->
</body>

</html>