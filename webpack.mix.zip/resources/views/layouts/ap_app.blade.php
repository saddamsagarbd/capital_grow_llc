@include('common.header')
@include('common.nav')
@yield('main-content')
@include('common.footer')
