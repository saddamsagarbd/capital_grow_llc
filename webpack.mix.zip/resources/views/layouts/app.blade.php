@include('auth.auth_common.header')
@yield('auth-content')
@include('auth.auth_common.footer')