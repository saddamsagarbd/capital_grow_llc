

<?php $__env->startSection('custom-style'); ?>
    <style type="text/css">
        @media  only screen and (max-width: 760px)  {
            /* Force table to not be like tables anymore */
            table, thead, tbody, th, td, tr { 
                display: block; 
            }

            /* Hide table headers (but not display: none;, for accessibility) */
            thead tr { 
                position: absolute;
                top: -9999px;
                left: -9999px;
            }

            tr { border: 1px solid #ccc; }

            td { 
                /* Behave  like a "row" */
                border: none;
                border-bottom: 1px solid #eee; 
                position: relative;
                padding-left: 50%; 
                text-align: right;
            }

            td:before { 
                /* Now like a table header */
                position: absolute;
                /* Top/left values mimic padding */
                top: 18px;
                left: 10px;
                width: 100%; 
                padding-right: 10px; 
                white-space: nowrap;
                text-align: left;
                color: #5983e8;
                font-weight: 500;
            }

            /*
            Label the data
            */
            td:nth-of-type(1):before { content: "SL"; }
            td:nth-of-type(2):before { content: "Username"; }
            td:nth-of-type(3):before { content: "Full Name"; }
            td:nth-of-type(4):before { content: "Contact No"; }
            td:nth-of-type(5):before { content: "Email"; }
            td:nth-of-type(6):before { content: "Status"; }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <ul class="list-arrow">
                            <?php if(count($users) > 0): ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="tree-li">
                                        <i class="fa fa-caret-right tree-right-arrow" data-p_id="<?php echo e($user->uid); ?>"></i><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                        <ul class="list-arrow">
                                            <div class="append-tree-child"></div>
                                            <div class="clr"></div>
                                        </ul>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <li>No users found</li>
                            <?php endif; ?>
                        </ul>
                        <!-- <div class="table-responsive">
                            <table class="table table-hover pending-users-list">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Username</th>
                                        <th>Full Name</th>
                                        <th>Contact No</th>
                                        <th>Email</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($user->username); ?></td>
                                        <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                                        <td><?php echo e($user->contact_number); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-icons btn-rounded btn-info">
                                                <i class="mdi mdi-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>
<script>
    $(function(){
        $(document).on("click", ".tree-right-arrow", function(){

            if($(this).hasClass("fa-caret-right"))
            {
                $(this).addClass("fa-caret-down");
                $(this).removeClass("fa-caret-right");

                var placementId = $(this).data('p_id');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $(this).closest("li.tree-li").find('ul.list-arrow .append-tree-child').html('');

                $.ajax({
                    type: 'post',
                    url: "<?php echo e(url('/')); ?>/get-refered-users",
                    data: { placementId }, // here $(this) refers to the ajax object not form
                    dataType: 'JSON',
                    success: function (res) {
                        console.log(res.html);                        
                        console.log($(this).closest("li.tree-li"));                        
                        $(this).closest("li.tree-li").find('ul.list-arrow .append-tree-child').append(res.html);
                    }
                });
            }
            else if($(this).hasClass("fa-caret-down"))
            {
                $(this).addClass("fa-caret-right");
                $(this).removeClass("fa-caret-down");
            }
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ap_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\future_increase\resources\views/admin_panel/referal_users.blade.php ENDPATH**/ ?>