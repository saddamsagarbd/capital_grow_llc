      <?php
        $full_name = getFullName(Auth::user()->user_id);
        $img_name = getProfileImage(Auth::user()->user_id);
        $imgSrc = '/images/profile_img/default_profile_img.png';

        if($img_name != "") $imgSrc = '/uploads/profile_images/'.$img_name;
      ?>
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="user-wrapper">
                <div class="profile-image">
                  <img src="<?php echo e(URL::to('/')); ?><?= $imgSrc; ?>" alt="profile image">
                </div>
                <div class="text-wrapper">
                  <p class="profile-name"><?php echo e($full_name); ?></p>
                  <div>
                    <?php
                      $badge = "Guest Board";
                      $imgSrc = '';
                      if (\Auth::user()->user_on_board == 1){
                        $badge = "Golden Board";
                        $imgSrc = 'dollar-coin.png';
                      }elseif (\Auth::user()->user_on_board == 2){
                        $badge = "Diamond Board";
                        $imgSrc = 'diamond.png';
                      }
                    ?>
                    <small class="designation text-muted"><?php echo e($badge); ?></small>
                    <!-- <span class="status-indicator online"></span> -->
                    <?php if($imgSrc != ""): ?>
                      <img src="<?php echo e(URL::to('/')); ?><?= '/images/'.$imgSrc; ?>" width="15px" alt="badge">
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <?php if(Auth::user()->user_status == 1): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
                <i class="menu-icon mdi mdi-television"></i>
                <span class="menu-title">Dashboard</span>
              </a>
            </li>
            <?php if(Auth::user()->user_role == 1): ?>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <i class="menu-icon mdi mdi-account-key"></i>
                <span class="menu-title">User Management</span>
                <i class="menu-arrow"></i>
              </a>
              <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/active-users')); ?>">Active Users List</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/pending-users')); ?>">Pending Users List</a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/withdrawal-requests')); ?>">
                <i class="menu-icon mdi mdi-transfer"></i>
                <span class="menu-title">All Withdrawal Requests</span>
              </a>
            </li>
            <?php endif; ?>
            <?php if(Auth::user()->user_role == 2): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/joining')); ?>">
                <i class="menu-icon mdi mdi-share-variant"></i>
                <span class="menu-title">Joining</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/refered-users')); ?>">
                <i class="menu-icon mdi mdi-account-multiple"></i>
                <span class="menu-title">Refered Users</span>
              </a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/earning-statement')); ?>">
                <i class="menu-icon mdi mdi-currency-usd"></i>
                <span class="menu-title">Earning Statement</span>
              </a>
            </li>
            <?php if(Auth::user()->user_role == 2): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/balance-withdrawal')); ?>">
                <i class="menu-icon mdi mdi-cash-multiple"></i>
                <span class="menu-title">Balance Withdrawal</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/withdrawal-request')); ?>">
                <i class="menu-icon mdi mdi-view-list"></i>
                <span class="menu-title">Withdrawal Request</span>
              </a>
            </li>
            <?php endif; ?>
          <?php else: ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/confirm-payment')); ?>">
                <i class="menu-icon mdi mdi-account-check"></i>
                <span class="menu-title">Confirm Payment</span>
              </a>
            </li>
          <?php endif; ?>
          <!-- <li class="nav-item">
            <a class="nav-link" href="pages/icons/font-awesome.html">
              <i class="menu-icon mdi mdi-sticker"></i>
              <span class="menu-title">Icons</span>
            </a>
          </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
              <i class="menu-icon mdi mdi-restart"></i>
              <span class="menu-title">Earning</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="auth">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                  <a class="nav-link" href="pages/samples/blank-page.html"> Refer Earn </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pages/samples/login.html"> Login </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pages/samples/register.html"> Register </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pages/samples/error-404.html"> 404 </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pages/samples/error-500.html"> 500 </a>
                </li>
              </ul>
            </div>
          </li> -->
        </ul>
      </nav>
      <!-- partial --><?php /**PATH C:\xampp\htdocs\capital_grow_llc\resources\views/common/nav.blade.php ENDPATH**/ ?>