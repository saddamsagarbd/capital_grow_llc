

<?php $__env->startSection('app-name'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
            <div class="card card-statistics">
                <div class="card-body">
                    <div class="clearfix">
                    <div class="float-left">
                        <i class="mdi mdi-cube text-danger icon-lg"></i>
                    </div>
                    <div class="float-right">
                        <p class="mb-0 text-right">Total Revenue</p>
                        <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0">$<?php echo e($balance); ?></h3>
                        </div>
                    </div>
                    </div>
                    <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-alert-octagon mr-1" aria-hidden="true"></i> 65% lower growth
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
            <div class="card card-statistics">
            <div class="card-body">
                <div class="clearfix">
                <div class="float-left">
                    <i class="mdi mdi-receipt text-warning icon-lg"></i>
                </div>
                <div class="float-right">
                    <p class="mb-0 text-right">Referal Users</p>
                    <div class="fluid-container">
                    <h3 class="font-weight-medium text-right mb-0"><?php echo e($totalReferal); ?></h3>
                    </div>
                </div>
                </div>
                <p class="text-muted mt-3 mb-0">
                <i class="mdi mdi-bookmark-outline mr-1" aria-hidden="true"></i> Product-wise sales
                </p>
            </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
            <div class="card card-statistics">
            <div class="card-body">
                <div class="clearfix">
                <div class="float-left">
                    <i class="mdi mdi-poll-box text-success icon-lg"></i>
                </div>
                <div class="float-right">
                    <p class="mb-0 text-right">Golden Board Rank</p>
                    <div class="fluid-container">
                    <h3 class="font-weight-medium text-right mb-0"><?php echo e(isset($getGoldenBoardDtl->id)?$getGoldenBoardDtl->id:'N/A'); ?></h3>
                    </div>
                </div>
                </div>
                <p class="text-muted mt-3 mb-0">
                <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i> Weekly Sales
                </p>
            </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
            <div class="card card-statistics">
            <div class="card-body">
                <div class="clearfix">
                <div class="float-left">
                    <i class="mdi mdi-poll-box text-success icon-lg"></i>
                </div>
                <div class="float-right">
                    <p class="mb-0 text-right">Golden Board Rank</p>
                    <div class="fluid-container">
                    <h3 class="font-weight-medium text-right mb-0"><?php echo e(isset($getGoldenBoardDtl->id)?$getGoldenBoardDtl->id:'N/A'); ?></h3>
                    </div>
                </div>
                </div>
                <p class="text-muted mt-3 mb-0">
                <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i> Weekly Sales
                </p>
            </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="card">
            <div class="card-body">
                <div class="row d-none d-sm-flex mb-4">
                <div class="col-4">
                    <h5 class="text-primary">Unique Visitors</h5>
                    <p>34657</p>
                </div>
                <div class="col-4">
                    <h5 class="text-primary">Bounce Rate</h5>
                    <p>45673</p>
                </div>
                <div class="col-4">
                    <h5 class="text-primary">Active session</h5>
                    <p>45673</p>
                </div>
                </div>
                <div class="chart-container">
                <canvas id="dashboard-area-chart" height="80"></canvas>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6 grid-margin">
            <div class="card">
            <div class="card-body">
                <h4 class="card-title"><img src="<?php echo e(URL::to('/')); ?><?= '/images/dollar-coin.png'; ?>" width="25px" alt="badge">Top 5 Golden Board Members</h4>
                <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Profile Image</th>
                        <th>Full name</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $getTofiveGoldenBoardMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gbmem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-weight-medium"><?php echo e(++$key); ?></td>
                        <td>
                            <div class="profile-image">
                                <?php
                                    $proimgSrc = '/images/profile_img/default_profile_img.png';

                                    if($gbmem->profile_img != "") $proimgSrc = '/uploads/profile_images/'.$gbmem->profile_img;                                
                                ?>
                                <img src="<?php echo e(URL::to('/')); ?><?= $proimgSrc; ?>" alt="profile image">
                            </div>
                        </td>
                        <td><?php echo e($gbmem->first_name); ?>&nbsp;<?php echo e($gbmem->last_name); ?></td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
            </div>
        </div>
        <div class="col-lg-6 grid-margin">
            <div class="card">
            <div class="card-body">
                <h4 class="card-title"><img src="<?php echo e(URL::to('/')); ?><?= '/images/diamond.png'; ?>" width="25px" alt="badge">Top 5 Diamond Board Members</h4>
                <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Profile Image</th>
                        <th>Full name</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $getTofiveDiamondBoardMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dbmem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-weight-medium"><?php echo e(++$key); ?></td>
                        <td>
                            <div class="profile-image">
                                <?php
                                    $proimgSrc = '/images/profile_img/default_profile_img.png';

                                    if($dbmem->profile_img != "") $proimgSrc = '/uploads/profile_images/'.$dbmem->profile_img;                                
                                ?>
                                <img src="<?php echo e(URL::to('/')); ?><?= $proimgSrc; ?>" alt="profile image">
                            </div>
                        </td>
                        <td><?php echo e($dbmem->first_name); ?>&nbsp;<?php echo e($dbmem->last_name); ?></td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ap_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\capital_grow_llc\resources\views/admin_panel/dashboard.blade.php ENDPATH**/ ?>