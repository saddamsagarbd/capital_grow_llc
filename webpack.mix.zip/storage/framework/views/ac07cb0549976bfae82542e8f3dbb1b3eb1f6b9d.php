<!-- plugins:js -->
<script src="<?php echo e(asset('/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(asset('/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/misc.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/scripts.js')); ?>"></script>
  <!-- endinject -->
</body>

</html><?php /**PATH C:\xampp\htdocs\capital_grow_llc\resources\views/auth/auth_common/footer.blade.php ENDPATH**/ ?>