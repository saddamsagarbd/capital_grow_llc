

<?php $__env->startSection('custom-style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>	
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12 grid-margin">
                <div class="card">
                    <div class="card-body pending-user-form">
                        <hr>
                        <h4 class="card-description">Personal Account Information</h4>
                        <div class="alert alert-danger error-msg" style="display:none;">
                            
                        </div>
                        <hr>
                        <h4>Total Balance: $<?php echo e(isset($balance)?$balance:'0.00'); ?></h4>
                        <p style="color: #fe7758 !important; font-size: 13px; font-weight: 500 !important; line-height: 23px !important;">Note: Vat(10%) and Tax(5%) charge will be added with Transfer/Withdrawal amount</p>
                        <div class="clr" style="height:20px;"></div>

                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('error')); ?>

                            </div>
                            <hr>
                        <?php endif; ?>

                        <?php if($existingWithdrawalRequest == true): ?>
                            <div class="alert alert-warning">
                                You already have a pending request for withdrawal. You can able to apply for request after accept/decline your request. Thank you.
                            </div>
                            <hr>
                        <?php else: ?>
                        
                        <form class="form-sample" action="<?php echo e(route('withdrawal-balance')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="balance" value="<?php echo e(isset($balance)?$balance:0); ?>">
                            <!-- <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Type</label>
                                        <div class="col-sm-9">
                                            <select class="form-control bw_type <?php $__errorArgs = ['bw_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bw_type">
                                                <option value="1">Balance Withdrawal</option>
                                                <option value="2">Fund Transfer</option>
                                            </select>
                                            <?php $__errorArgs = ['bw_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div> -->

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Amount</label>
                                        <div class="col-sm-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">$</span>
                                                </div>
                                                <input type="number" class="form-control withdrawal_amount <?php $__errorArgs = ['withdrawal_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('withdrawal_amount')); ?>" name="withdrawal_amount" placeholder="e.g. 185" required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">.00</span>
                                                </div>
                                            </div>
                                            <!-- <input type="text" class="form-control username <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('username')); ?>" name="username" placeholder="e.g johndoe" required> -->
                                            <?php $__errorArgs = ['withdrawal_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group row">
                                        <label class="col-sm-5 col-form-label">Vat(10%)</label>
                                        <div class="col-sm-7">
                                            <div class="input-group">
                                                <input type="number" class="form-control vat_amount <?php $__errorArgs = ['vat_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('vat_amount')); ?>" name="vat_amount" readonly required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">.00</span>
                                                </div>
                                            </div>
                                            <!-- <input type="text" class="form-control username <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('username')); ?>" name="username" placeholder="e.g johndoe" required> -->
                                            <?php $__errorArgs = ['vat_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group row">
                                        <label class="col-sm-5 col-form-label">Tax(5%)</label>
                                        <div class="col-sm-7">
                                            <div class="input-group">
                                                <input type="number" class="form-control tax_amount <?php $__errorArgs = ['tax_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('tax_amount')); ?>" readonly name="tax_amount" required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">.00</span>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['tax_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Total</label>
                                        <div class="col-sm-9">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">$</span>
                                                </div>
                                                <input type="number" class="form-control total_amount <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('total_amount')); ?>" name="total_amount" readonly required>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">.00</span>
                                                </div>
                                            </div>
                                            <!-- <input type="text" class="form-control username <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('username')); ?>" name="username" placeholder="e.g johndoe" required> -->
                                            <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row" id="otp-section" style="display: none;">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">OTP</label>
                                        <div class="col-sm-9">
                                            <input type="number" class="form-control otp <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('otp')); ?>" name="otp" placeholder="e.g johndoe">
                                            <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="button" class="btn btn-success mr-2 nextBtn" data-user_id="<?php echo e(Auth::user()->id); ?>">Next</button>
                            <button type="submit" class="btn btn-success mr-2 submitBtn" style="display: none;">Submit</button>
                            <button type="reset" class="btn btn-light">Cancel</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- content-wrapper ends -->	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-script'); ?>
<script type="text/javascript">
    $(function(){
        $(".submitBtn").hide();
        $(document).on("change", ".withdrawal_amount", function(){
            var wAmt = $(this).val();
            var vatAmt = parseFloat(parseFloat(wAmt) * 0.1);
            var taxAmt = parseFloat(parseFloat(wAmt) * 0.05);
            var total = parseFloat(parseFloat(wAmt) + parseFloat(vatAmt) + parseFloat(taxAmt));

            var prevBalance = $("input[name='balance']").val();

            $(".error-msg").attr('style', 'display: none');
            $(".error-msg").html('');
            $(".nextBtn").prop("disabled", false);

            if(total > parseFloat(prevBalance)){
                $(".error-msg").removeAttr("style");
                $(".error-msg").html("Withdrawal amount can not be greater then balance amount.");
                $(".nextBtn").prop("disabled", true);
            }

            $(".vat_amount").val(vatAmt);
            $(".tax_amount").val(taxAmt);
            $(".total_amount").val(total);
        });

        function sendOtp(id)
        {
            $.ajax({
                type: 'POST',
                url: "<?php echo e(url('/')); ?>/send-otp",
                data: {'id' : id}, // here $(this) refers to the ajax object not form
                dataType: 'JSON',
                success: function (res) {

                    $("#otp-section").hide();
                    $(".error-msg").attr('style', 'display: none');
                    $(".error-msg").html('');
                    $(".nextBtn").show();
                    $(".submitBtn").hide();
                    if(res.status == true){
                        $("#otp-section").show();
                        $(".nextBtn").hide();
                        $(".submitBtn").show();
                    }else{
                        $(".error-msg").removeAttr("style");
                        $(".error-msg").html("OTP not sent. Please try after sometime!");
                    }
                },
            });
        }

        $(document).on("click", ".nextBtn", function(e){

            var id = $(this).data('user_id');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            sendOtp(id);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ap_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\future_increase\resources\views/admin_panel/balance_withdrawal.blade.php ENDPATH**/ ?>