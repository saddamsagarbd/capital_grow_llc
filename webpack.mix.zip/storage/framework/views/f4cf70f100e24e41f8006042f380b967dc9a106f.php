

<?php $__env->startSection('app-name'); ?>
    Add Account Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>	
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12 grid-margin">
                <div class="card">
                    <div class="card-body pending-user-form">
                        <hr>
                        <h4 class="card-description">Personal Account Information</h4>
                        <hr>
                        <form class="form-sample" action="<?php echo e(route('save-account-info')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Banking Type</label>
                                        <div class="col-sm-9">
                                            <select class="form-control banking_type <?php $__errorArgs = ['banking_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="banking_type">
                                                <option value="1">Mobile Banking</option>
                                                <option value="2">Personal/Business Banking</option>
                                            </select>
                                            <?php $__errorArgs = ['banking_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="indv-bus-banking" style="display: none;">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Account Title</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control <?php $__errorArgs = ['acc_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('acc_title')); ?>" name="acc_title" placeholder="e.g. John Doe">
                                        <?php $__errorArgs = ['acc_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Account No</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control ac_no <?php $__errorArgs = ['ac_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('ac_no')); ?>" name="ac_no" placeholder="e.g. XXX.XXXX.XXX">
                                        <?php $__errorArgs = ['ac_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Bank Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('bank_name')); ?>" name="bank_name" placeholder="e.g. Bank Name Here">
                                        <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Branch Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control <?php $__errorArgs = ['branch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('branch_name')); ?>" name="branch_name" placeholder="e.g. Branch Name Here">
                                        <?php $__errorArgs = ['branch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row" id="mobile-banking">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Operator</label>
                                        <div class="col-sm-9">
                                            <select class="form-control operator <?php $__errorArgs = ['operator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="operator" required>
                                                <option value="1">BKash</option>
                                                <option value="2">DBBL Rocket</option>
                                                <option value="3">Nagad</option>
                                            </select>
                                            <?php $__errorArgs = ['operator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Mobile A/C No</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control mbl_ac_no <?php $__errorArgs = ['mbl_ac_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('mbl_ac_no')); ?>" name="mbl_ac_no" placeholder="e.g 01XXX XXX XXX" required>
                                        <?php $__errorArgs = ['mbl_ac_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Account type</label>
                                        <div class="col-sm-9">
                                            <select class="form-control ac_type <?php $__errorArgs = ['ac_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ac_type" required>
                                                <option value="1">Personal</option>
                                                <option value="2">Agent</option>
                                                <option value="3">Marchent</option>
                                            </select>
                                            <?php $__errorArgs = ['ac_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-success mr-2 submitBtn">Submit</button>
                            <button type="reset" class="btn btn-light">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- content-wrapper ends -->	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-script'); ?>
<script type="text/javascript">
    $(function(){

        /**
            checkMblAccountExist() has two params mobile account number and second one is account operator
        */
        function checkMblAccountExist(mblAcNo, acOpt)
        {
            $.ajax({
                type: 'POST',
                url: "<?php echo e(url('/')); ?>/get-referral-name",
                data: {'username' : username}, // here $(this) refers to the ajax object not form
                dataType: 'JSON',
                success: function (res) {
                    console.log(res);
                    var msg = "";
                    
                    $(document).find('span.'+ msgfor +'_name').html('');
                    
                    if( typeof res === 'undefined' || res === null ){
                        msg = "User not found/exist";
                    }else{
                        var fullName = res.first_name +" "+ res.last_name;
                        msg = '['+ fullName +']';
                    }
                    
                    $(document).find('span.'+ msgfor +'_name').html(msg);
                },
            });
        }

        $(document).on("change", ".mbl_ac_no", function(e){
            e.preventDefault();
            $(document).find(".submitBtn").prop("disabled", false);
            var mblAcNo = $(this).val();
            var acOpt = $(".operator").val();
            
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            if(mblAcNo.length > 11 || mblAcNo.length < 11){
                alert("Mobile Account Number must be 11 digit");
                $(document).find(".submitBtn").prop("disabled", true);
                return false;
            }

            if(mblAcNo.length == 11){
                checkMblAccountExist(mblAcNo, acOpt);
            }

        });

        $(document).on("change", ".banking_type", function(){
            $(document).find("#mobile-banking").hide();
            $(document).find("#mobile-banking :not(:checkbox)").prop("required", false);

            $(document).find("#indv-bus-banking").hide();
            $(document).find("#indv-bus-banking :not(:checkbox)").prop("required", false);
            
            if($(this).val() == 1){
                $(document).find("#mobile-banking").show();
                $(document).find("#mobile-banking :not(:checkbox)").prop("required", true);
            }else if($(this).val() == 2){
                $(document).find("#indv-bus-banking").show();
                $(document).find("#indv-bus-banking :not(:checkbox)").prop("required", true);
            }
        });

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ap_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\capital_grow_llc\resources\views/admin_panel/add_account_info_form.blade.php ENDPATH**/ ?>