

<?php $__env->startSection('app-name'); ?>
    Pending User List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-style'); ?>
<style type="text/css">
    @media  only screen and (max-width: 760px)  {
        /* Force table to not be like tables anymore */
        table, thead, tbody, th, td, tr { 
            display: block; 
        }

        /* Hide table headers (but not display: none;, for accessibility) */
        thead tr { 
            position: absolute;
            top: -9999px;
            left: -9999px;
        }

        tr { border: 1px solid #ccc; }

        td { 
            /* Behave  like a "row" */
            border: none;
            border-bottom: 1px solid #eee; 
            position: relative;
            padding-left: 50%; 
            text-align: right;
        }

        td:before { 
            /* Now like a table header */
            position: absolute;
            /* Top/left values mimic padding */
            top: 18px;
            left: 10px;
            width: 100%; 
            padding-right: 10px; 
            white-space: nowrap;
            text-align: left;
            color: #5983e8;
            font-weight: 500;
        }

        /*
        Label the data
        */

        td:nth-of-type(1):before { content: "SL"; }
        td:nth-of-type(2):before { content: "Username"; }
        td:nth-of-type(3):before { content: "Details"; }
        td:nth-of-type(4):before { content: "Amount ($)"; }
        td:nth-of-type(5):before { content: "Payment Date"; }
        td:nth-of-type(6):before { content: "Status"; }
        td:nth-of-type(7):before { content: "Action"; }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover pending-users-list">
                                <thead>
                                    <tr>
                                        <th style="width: 5%">SL</th>
                                        <th>Username</th>
                                        <th style="width: 25%">Details</th>
                                        <th>Amount ($)</th>
                                        <th>Payment Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/user-details/'.$user->user_id)); ?>">
                                                <?php echo e($user->username); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <?php
                                                $pm = "Bkash";
                                                if($user->pay_to == 2){
                                                    $pm = "DBBL Rocket";
                                                } else if($user->pay_to == 3){
                                                    $pm = "Nagad";
                                                } else if($user->pay_to == 4){
                                                    $pm = "Bank Deposite";
                                                }
                                            
                                            ?>
                                            Payment made in <strong><?php echo e($pm); ?></strong></br>
                                            on Ac/No <strong><?php echo e($user->pay_to_ac); ?></strong></br>
                                            trxn no is <strong><?php echo e($user->transaction_no); ?></strong>
                                        </td>
                                        <td><?php echo e("$".number_format($user->paid_amount,2,".","")); ?></td>
                                        <td><?php echo e(date("d-m-Y", strtotime($user->payment_date))); ?></td>
                                        <td>
                                            <label class="badge badge-danger">Pending</label>
                                        </td>
                                        <td>
                                            <button class="btn btn-info btn-xs make_confirm" data-user_id="<?php echo e($user->user_id); ?>">Confirm</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>
<script>
    $(function(){
        $('.pending-users-list').DataTable( {
            responsive: true
        });
        function ajaxCall(userId)
        {
            $.ajax({
                type: 'POST',
                url: "<?php echo e(url('/')); ?>/confirm-payment",
                data: {'user_id' : userId}, // here $(this) refers to the ajax object not form
                dataType: 'JSON',
                success: function (res) {
                    if(res.status == true){
                        location.reload();
                    }
                }
            });
        }

        $(document).on("click", ".make_confirm", function(e){
            e.preventDefault();
            var userID = $(this).data("user_id");
            $(this).prop('disabled', true);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            ajaxCall(userID);
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ap_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\capital_grow_llc\resources\views/admin_panel/pending_list.blade.php ENDPATH**/ ?>